from substra.sdk.backends.local.compute.worker import Worker


__all__ = [
    'Worker',
]
